/* [Thank You] First 100 Downloads Exclusive [DLC] | Load Script Through DLoad | Minecraft 1.12.2 (05Jul20) | Written by Rimscar */
var DLC = {
    DLOAD_VERSION: 1,
    CATEGORY: "TRINKET",
    MESSAGE: "§e[§6§lFIRST 100 DOWNLOADS§e]",
    ITEMS: [
        "§e[§6§lDLC§e] §2§lBlack Christmas@0minecraft:skull@4ee53f881-8b67-4604-bfb9-a43a6966eae2$eyJ0ZXh0dXJlcyI6eyJTS0lOIjp7InVybCI6Imh0dHA6Ly90ZXh0dXJlcy5taW5lY3JhZnQubmV0L3RleHR1cmUvNWM3MTJiMTk3MWM1ZjQyZWVmZjgwNTUxMTc5MjIwYzA4YjgyMTNlYWNiZTZiYzE5ZDIzOGMxM2Y4NmUyYzAifX19@1§d§o* Rare §c[Trinket]@1§7@1§8Menacing black box tied with@1§8green ribbons. Dealing DMG@1§8has a small chance to start@1§8a '§7Secret Santa§8' in which@1§8several gifts are given.@1§8@1§7When in off hand:@1§9 +4 Attack Damage@1§9 * Receive Gifts@1§c * Santa Black as Night@2SCRIPTED@2RARE@2TRINKET@2OFFHAND@2BCHRISTMAS@2FIRST100@2DLC@34.0$offhand$generic.attackDamage$-8244461935324938044L$-8768409221133575906L@52@63"
    ],
    TRINKET_TAG: "FIRST100",
    TRINKET_SCRIPTS_OFFHAND: [
        {
            tag: "CHRISTMASORB",
            Tick: function Tick(e){
                var ne = e.player.world.getNearbyEntities(e.player.pos, 16, 2);
                for(var i = 0; i < ne.length; i++){
                    if (ne[i].getFaction().playerStatus(e.player) == -1){
                        var elf = e.player.world.spawnClone(ne[i].x+1, ne[i].y, ne[i].z, 5, "F100 Christmas Elf");
                        elf.getRole().setInfinite(true);
                        elf.getRole().setFollowing(e.player);
                    }
                }
                Audio.Play("ho_2");
                Utilities.Broadcast("&cThe elves are hungry");
                BTManager12.RemoveItem(e, 'o');
            }
        },
        {
            tag: "BCHRISTMAS",
            Kill: function Kill(e){ 
                if (Math.random() < 0.2){
                    if (Math.random() < 0.75){
                        DigitalTrinkets12.Give(this.gifts[Math.floor(Math.random()*this.gifts.length)]);
                    }
                    else {
                        DigitalTrinkets12.Give(this.rareGifts[Math.floor(Math.random()*this.rareGifts.length)]);
                    }
                }
                else if (Math.random() < 1.03){ // roughly 1/50 chance
                    this.BlackSanta(e);
                }
            },

            BlackSanta: function BlackSanta(e){
                var loc = Utilities.GetSafeLocationNearEntity(e.player, 5, 20);
                var santa = e.player.world.spawnClone(loc.x, loc.y, loc.z, 5, "F100 SANTA BLACK");
                santa.setAttackTarget(e.player);
            },

            gifts: [
                "§cApple Cream Pie@0minecraft:pumpkin_pie@1§fA traditional staple from@1§fCongrejo Island. Not only@1§fis the apple within deeply@1§fflavorful. But the cream@1§fhas also maintatined it's@1§fsweetness and moisture@1§fthrough baking.@2APPLEPIE@2FOOD",
                "§8Gingerbread Man@0minecraft:bread@1§7Treats such as these are@1§7popular among island-round@1§7holidays, such as Yarrmas.@2GINGERBREADMAN@2FOOD",
                "§8§lGingerbread House@0minecraft:bread@1§7Completly edible, even the@1§7gnome who lives within.@2GINGERBREADHOUSE@2FOOD",
                "§cCandied Apple@0minecraft:apple@1§eAn Apple covered in a@1§esugary, candy coating.@2CANDYAPPLE@2FOOD@53,ench:[{id:51s,lvl:1s}]",
                "§8Yarrmas Cookie@0minecraft:cookie@1§7The cookie features a@1§7Yarrmas tree made entirely@1§7out of lemon cream.@2GINGERBREADCOOKIE@2FOOD",
            ],
            rareGifts: [
                "§c§lMonster Balls@0minecraft:spider_eye@1§7A healthy portion of balls@1§7sauteed in a mushroom sauce.@1§7§oA rocky mountain specialty.~@2MONSTERBALLS@2FOOD",
                "§7§lMeat of Mushrooms Gone §c§lBAD@0minecraft:beetroot@1§7Steaming mushrooms piled high on a@1§7platter of back-of-the-shelf meat.@1§7It is clear that this must be eaten@1§7right away, less it expire.@2MEATMUSHROOMBAD@2FOOD",
                
                "§9Death Orb@0variedcommodities:orb@1§a§o* Common §b[Orb]@1§7@1§7When in off hand:@1§c Harms the user@2SCRIPTED@2OFFHAND@2ORB@2COMMON@2TROPICORB@2DEATHORB@612",
                "§9Experience Orb@0variedcommodities:orb@1§d§o* Rare §b[Orb]@1@1§7When in off hand:@1§9 Grants Experience Levels@2SCRIPTED@2OFFHAND@2ORB@2RARE@2CROWORB@2EXPERIENCEORB@612",
            ]
        },
    ],
    TRINKET_SCRIPTS_MAINHAND: []
}